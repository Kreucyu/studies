package entities;

public class MapaDispersao<T> {
	private ListaEncadeada<NoMapa<T>> info[];

	public ListaEncadeada<NoMapa<T>>[] getInfo() {
		return info;
	}

	public void setInfo(ListaEncadeada<NoMapa<T>> info[]) {
		this.info = info;
	}

	@SuppressWarnings("unchecked")
	public MapaDispersao(int tamanho) {
		info = new ListaEncadeada[tamanho];
	}

	private int calcularHash(int chave) {
		int tamanho = getInfo().length;
		return chave % tamanho;
	}

	public void inserir(int chave, T dado) {
		int idx = calcularHash(chave);
		if (info[idx] == null) {
			info[idx] = new ListaEncadeada<>();
		}
		NoMapa<T> no = new NoMapa<T>();
		no.setChave(chave);
		no.setValor(dado);
		info[idx].inserir(no);
	}

	public void remover(int chave) {
		int idx = calcularHash(chave);
		NoMapa<T> no = new NoMapa<T>();
		no.setChave(chave);
		info[idx].retirar(no);
	}

	public T buscar(int chave) {
		int idx = calcularHash(chave);	
		if(info[idx] != null) {
			NoMapa<T> no = new NoMapa<T>();
			no.setChave(chave);
			NoLista<NoMapa<T>> result = info[idx].buscar(no);
			if(no != null) {
				return result.getInfo().getValor();
			}
		}
		return null;
	}

	public double calcularFatorCarga() {
		double tamanho = getInfo().length;
		double qtde = 0;
		for(ListaEncadeada<NoMapa<T>> n : info) {
			if(n != null) {
				qtde += n.obterComprimento();
			}
		}
		return qtde / tamanho;
	}

	public int calcularQtdeObjetos() {
		int obj = 0;
		for(ListaEncadeada<NoMapa<T>> n : info) {
			if(n != null) {
				obj += n.obterComprimento();
			}
		}
		return obj;
	}
}
